declare module 'short-uid'
